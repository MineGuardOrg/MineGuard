MineGuard Database CSV Backup
================================

Database: mineguard_db
Host: mysql-mineguard.mysql.database.azure.com
Date: 2025-11-24
Total Tables: 15

Tables included:
  - alert.csv
  - area.csv
  - connection.csv
  - device.csv
  - incident_report.csv
  - maintenance_log.csv
  - ml_prediction.csv
  - ml_training_data.csv
  - position.csv
  - reading.csv
  - role.csv
  - sensor.csv
  - shift.csv
  - user.csv
  - user_shift.csv

Each CSV file contains the complete data from its corresponding table.
Encoding: UTF-8 with BOM (compatible with Excel)
